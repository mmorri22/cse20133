# Privacy

The documentation for this topic has been moved to the following articles in [Microsoft Learn](https://learn.microsoft.com/vcpkg):

* [Privacy](https://learn.microsoft.com/vcpkg/about/privacy)
